import sys
import os

def validate_args(args):
    # Check if all arguments are filled
    if len(args) != 5:
        print("Usage: python <roll_no.py> <csv_file> <weights> <impact> <resultName>")
        return False

    # Extract arguments
    input_file = args[1]
    weights = args[2]
    impacts = args[3]
    output_file = args[4]

    # Check if the input file exists
    if not os.path.exists(input_file):
        print(f"Error: The file '{input_file}' does not exist.")
        return False

    # Validate weights
    try:
        weight_list = [float(w) for w in weights.split(',')]
    except ValueError:
        print("Error: Weights must be numbers separated by commas (e.g., '1,2,3').")
        return False

    # Validate impacts
    impact_list = impacts.split(',')
    if len(impact_list) != len(weight_list):
        print("Error: The number of impacts must match the number of weights.")
        return False

    for impact in impact_list:
        if impact not in ['+', '-']:
            print("Error: Impacts must only contain '+' or '-' and be separated by commas.")
            return False

    # Validation successful
    print("All CLI arguments are valid.")
    return True

if __name__ == "__main__":
    # Validate command-line arguments
    if not validate_args(sys.argv):
        sys.exit(1)
